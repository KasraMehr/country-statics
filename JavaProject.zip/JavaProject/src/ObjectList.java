
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mountain
 */
public class ObjectList {
    
    public static List<Human> humanList = new ArrayList<>();
    public static List<LowerDiploma> lowerDiplomaList = new ArrayList<>();
    public static List<HigherDiploma> higherDiplomaList = new ArrayList<>();
    public static List<Employeed> employedList = new ArrayList<>();
    
    public static List<Animal> animalList = new ArrayList<>();
    public static List<Fish> fishList = new ArrayList<>();
    public static List<Bird> birdList = new ArrayList<>();
    public static List<Mammal> mammalList = new ArrayList<>();
    public static List<SpecialAnimals> specialAnimalsList = new ArrayList<>();
    
    public static List<Plants> plantsList = new ArrayList<>();
    public static List<Flower> flowerList = new ArrayList<>();
    public static List<Tree> treeList = new ArrayList<>();
    public static List<Medical> medicalList = new ArrayList<>();
    public static List<SpecialPlants> specialPlantsList = new ArrayList<>();
    
    public static List<LandSources> landSourcesList = new ArrayList<>();
    public static List<Land> landList = new ArrayList<>();
    public static List<Water> waterList = new ArrayList<>();
    public static List<SpecialLandSource> specialLandSourceList = new ArrayList<>();
}
